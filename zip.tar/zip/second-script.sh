#! /bin/sh
# this often contains a symbolic link to bash i.e Bourne Shell

echo "Hello        World"
echo "Hello World"
echo "Hello * World"
echo Hello * World
echo Hello     World
echo "Hello" World
echo Hello "    " World
echo "Hello "*" World"
echo 'hello' world
echo `hello` world
