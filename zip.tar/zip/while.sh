#! /bin/sh

INPUT_STR="hello"

while [ "$INPUT_STR" != "bye" ]
do
  echo "Please type something (bye to quit)"
  read INPUT_STR
  echo "you typed : $INPUT_STR"
done
