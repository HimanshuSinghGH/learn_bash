#! /bin/sh

echo "my var is $MY_VAR"
MY_VAR="hi there"
echo "my var is $MY_VAR"
