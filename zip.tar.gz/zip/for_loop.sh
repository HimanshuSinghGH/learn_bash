#! /bin/sh

for i in 1 2 3 4 5
do
  echo "value of i is $i"
done
