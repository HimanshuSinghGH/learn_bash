#! /bin/sh

for i in hello 1 * 2 bye
do
  echo "value of i is $i"
done
