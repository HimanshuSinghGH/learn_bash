#! /bin/sh

#MY_MESSAGE="Hello World"

read MY_MESSAGE

echo "HELLO $MY_MESSAGE ! How're you doing?"
