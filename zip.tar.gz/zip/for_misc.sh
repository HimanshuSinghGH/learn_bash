#! /bin/bash

for runlevel in 0 1 2 3 4 5
do
  mkdir rc${runlevel}.d
done
