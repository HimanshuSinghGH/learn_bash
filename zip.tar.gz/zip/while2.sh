#! /bin/bash

while read f
do
  case $f in
       hello)	echo English	;;
       howdy)	echo American	;;
       gday)	echo AUstralian	;;
       namaste)	echo Indian	;;
	*)	echo "Unknown"	;;
  esac
done < myfile
